**TinyDog**


ReadMe:

Welcome to TinyDog! This README file serves as a guide to understanding
the project structure, setup instructions, and important details for developers and contributors.

Project Overview:

This project is basically to find a dog nearby you this project ia only have frontend part.
This is the first project i made in bootstrap to enhance my bootstrap framework knowledge.

Project Structure:

|-- index.html- # Main HTML file for the web page
|-- css/-  # Directory for CSS stylesheets

Tech Base Used:

As per the leading industry demands, we used the latest teach base and frameworks to create this web project.

|-- HTML
|-- CSS
|-- Bootstrap

**THE END**
